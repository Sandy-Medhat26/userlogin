## login & Register ( PHP Native )
#   OOP 



## Laravel 
- install 
- cmd artisan 
- routes 
- views 
- controller 


## Model 
- migration 
- login 
- Blog 
- API 
- collection 
- postman 


# Dashboard  






# schema 
- users 
  - id
  - name 
  - email 
  - password (hashing(md5))
  - date


## conn -



**Pages**
1) Register -> insertuser -> login
2) Login -> Checkuser (the same of insertuser)
3) logout->login


**fetch_assoc/loop**
- fetch_assoc->one data
- loop -> many data